//
//  BorderCalcView.swift
//  chafenqi
//
//  Created by 刘易斯 on 2023/2/1.
//

import SwiftUI

struct BorderCalcView: View {
    var song: ChunithmSongData
    
    var body: some View {
        VStack {
            HStack {
                
            }
        }
    }
}

struct BorderCalcView_Previews: PreviewProvider {
    static var previews: some View {
        BorderCalcView(song: tempSongData)
    }
}
